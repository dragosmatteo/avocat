jQuery(document).ready(function() {
        $(function () {
            $('#defaultCountdown').countdown({until: new Date(2021, 12-1, 10, 8)}); // year, month, date, hour
        });
});		

