@extends('app.master')

@section('meta')
<title>{{config('constant.constant.contact_seo_title.'.$lang)}}</title>
<meta name="description" content="{{config('constant.constant.contact_seo_desc.'.$lang)}}" />

{{-- <meta property="fb:app_id" content="1355208687908995" /> --}}
<meta property="og:type" content="website" />
<meta property="og:url" content="{{url()->current()}}" />
<meta property="og:image"    content="https://casadevis.md/assets/img/casadevis_{{ $lang }}.jpg" />
<meta property="og:title" content="{{config('constant.constant.contact_seo_title.'.$lang)}}" />
<meta property="og:description" content="{{config('constant.constant.contact_seo_desc.'.$lang)}}" />

<script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [{
        "@type": "ListItem",
        "position": 1,
        "name": "{{config('constant.constant.main.'.$lang)}}",
        "item": "{{route('home')}}"
      },{
        "@type": "ListItem",
        "position": 2,
        "name": "{{config('constant.constant.contact.'.$lang)}}"
      }]
    }
</script>
@endsection

@section('header')
<nav class="breadcrumb-nav">
    <div class="container">
        <ul class="breadcrumb">
            <li><a href="{{route('home')}}"><i class="d-icon-home"></i></a></li>
            <li>{{config('constant.constant.contact.'.$lang)}}</li>
        </ul>
    </div>
</nav>
@endsection

@section('content')
  <div class="page-content pt-7">
      <section class="contact-section">
          <div class="container">
              <div class="row">
                  <div class="col-lg-3 col-md-4 col-sm-6 ls-m mb-10">
                      <div class="grey-section d-flex align-items-center h-100">
                          <div>
                              <h4 class="mb-2">{{config('constant.constant.address.'.$lang)}}</h4>
                              <p>{{$about->address->$lang}}</p>

                              <h4 class="mb-2">{{config('constant.constant.phone.'.$lang)}}</h4>
                              <p>
                                  <a href="tel:{{ $about->phone_1 }}">{{ $about->phone_1 }}</a>
                                  <br>
                                  <a href="tel:{{ $about->phone_2 }}">{{ $about->phone_2 }}</a>
                              </p>

                              <h4 class="mb-2">{{config('constant.constant.email.'.$lang)}}</h4>
                              <p class="mb-4">
                                  <a href="mailto:{{ $about->email }}">{{ $about->email }}</a>
                              </p>
                          </div>
                      </div>
                  </div>
                  <div class="col-lg-9 col-md-8 col-sm-6 d-flex align-items-center mb-10">
                      <div class="w-100">
                          <form method="POST" action="{{route('feedback.store')}}">
                              <h4 class="ls-m font-weight-bold">{{config('constant.constant.action.'.$lang)}}</h4>
                              <br>
                              <div class="row mb-2">
                                <div class="col-md-6 mb-4">
                                    <input class="form_name form-control" type="text" name="name" placeholder="{{config('constant.constant.name.'.$lang)}}" required="required" data-error="{{config('constant.constant.name_error.'.$lang)}}" autocomplete="off">
                                </div>
                                <div class="col-md-6 mb-4">
                                    <input class="form_phone form-control" type="number" name="phone" placeholder="{{config('constant.constant.phone.'.$lang)}}" required="required" data-error="{{config('constant.constant.phone_error.'.$lang)}}" autocomplete="off">
                                </div>
                                <div class="col-12 mb-4">
                                    <textarea class="form-control form_message" rows="4" name="message" placeholder="{{config('constant.constant.message.'.$lang)}}"></textarea>
                                </div>
                              </div>
                              @csrf
                              <button class="btn btn-success btn-rounded newsletterbutton">{{config('constant.constant.send.'.$lang)}}</button>
                          </form>
                      </div>
                  </div>
              </div>
          </div>
      </section>

      <!-- Google Maps - Go to the bottom of the page to change settings and map location. -->
      <div class="grey-section google-map mt-5" id="googlemaps">
        {!! $about->map !!}
      </div>
      <!-- End Map Section -->
@endsection
