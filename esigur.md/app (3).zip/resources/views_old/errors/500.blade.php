@extends('app.master')

@section('meta')
<title>500</title>
<meta name="description" content="{{ config('constant.constant.error_body.'.$lang) }}"/>
@endsection

@section('content')
  @if (isset($about))
  <div class="box-gallery-vertical box-gallery-content section-margin" data-dsn-animate="section" data-dsn-duration="100%">
    <div class="mask-bg"></div>
    <div class="container">
      <div class="row align-items-center h-100 dsn-z-index-2">
        <div class="col-lg-6 dsn-z-index-2">
          <div class="box-im" data-dsn-grid="move-up">
            <picture>
              <source srcset="/files/abouts/lg/{{$about->image.'.webp'}}" type="image/webp" media="(min-width: 1025px)">
              <source srcset="/files/abouts/lg/{{$about->image.'.jpg'}}" type="image/jpeg" media="(min-width: 1025px)">
              <source srcset="/files/abouts/md/{{$about->image.'.webp'}}" type="image/webp" media="(min-width: 415px)">
              <source srcset="/files/abouts/md/{{$about->image.'.jpg'}}" type="image/jpeg" media="(min-width: 415px)">
              <source srcset="/files/abouts/sm/{{$about->image.'.webp'}}" type="image/webp">
              <source srcset="/files/abouts/sm/{{$about->image.'.jpg'}}" type="image/jpeg">
              <img src="/files/abouts/lg/{{ $about->image.'.jpg' }}" alt="{{$about->name->$lang}}" class="has-top-bottom" data-dsn-move="20%">
            </picture>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="box-info">
            <div class="title-cover" data-dsn-grid="move-section" data-dsn-opacity="0.1" data-dsn-duration="170%" data-dsn-move="0%">
              500
            </div>
            <div class="vertical-title ">
              <h1 class="dsn-text">{{config('constant.constant.error_title.'.$lang)}}</h1>
            </div>
            <div class="bg-mask-content dsn-up">
              <div class="mask-bg-2 background-section"></div>
              <h6 class="dsn-up">
                {{config('constant.constant.error_body.'.$lang)}}
              </h6>
            </div>
            <div class="d-inline-block dsn-up">
              <a href="{{route('home')}}" class="link-custom d-flex a-item-center p-relative effect-ajax-none">
                <span class="link-text">{{config('constant.constant.main.'.$lang)}}</span>
                <span class="link-circle p-absolute">
                  <i class="fas fa-arrow-right"></i>
                </span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  @endif

@endsection
