@if ($testimonials->count())
  <section class="pt-10 pb-10 testimonials-section overflow-hidden">
      <div class="container">
          <div class="title-wrapper text-center">
              <div class="title title-sm title-center title-custom-underline mb-8 appear-animate">
                {{config('constant.constant.testimonials.'.$lang)}}
              </div>
          </div>
          <div class="owl-carousel owl-theme" data-owl-options="{
              'margin':20,
              'nav':false,
              'dots':true,
              'responsive':{
                  '992':{
                      'items':3,
                      'nav':false,
                      'dots':true
                  },
                  '768':{
                      'items':2,
                      'nav':false,
                      'dots':true
                  },
                  '576':{
                      'items':1
                  },
                  '0':{
                      'items':1
                  }
              }
          }">
          @foreach ($testimonials as $key => $testimonial)
            <div class="testimonial testimonial-centered appear-animate" data-animation-options="{
                'name': 'fadeInLeftShorter',
                'delay': '.5s'
            }">
                <div class="testimonial-info">
                    <figure class="testimonial-author-thumbnail">
                      <picture>
                        <source srcset="/files/testimonials/{{$testimonial->image.'.webp'}}" type="image/webp">
                        <source srcset="/files/testimonials/{{$testimonial->image.'.jpg'}}" type="image/jpeg">
                        <img width="70" height="70" loading="lazy" src="/files/testimonials/{{$testimonial->image.'.jpg'}}" alt="{{$testimonial->name->$lang}}">
                      </picture>
                    </figure>
                    <blockquote>{{$testimonial->body->$lang}}</blockquote>
                    <cite>
                      {{$testimonial->name->$lang}}
                      {{-- <span>{{$testimonial->title->$lang}}</span> --}}
                    </cite>
                </div>
            </div>
          @endforeach
        </div>
      </div>
  </section>

@endif
