@if ($features->count())
  <section class="pb-10 pt-10 service-list-section p-relative overflow-hidden ">
      <div class="container">
        <div class="title-wrapper text-center">
            <div class="title title-sm mt-8 title-center title-custom-underline mb-8 appear-animate">
              {{config('constant.constant.feature_title.'.$lang)}}
            </div>
        </div>
          <div class="service-list service-list-lg appear-animate" data-animation-options="{
              'name': 'fadeInUpShorter',
              'delay': '.2s'
          }">
            <div class="row show-shadow">
              @foreach ($features as $key => $feature)
                @include('parts.feature')
              @endforeach
            </div>
          </div>
      </div>
  </section>
@endif
