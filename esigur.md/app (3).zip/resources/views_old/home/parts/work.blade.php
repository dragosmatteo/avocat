@if ($works->count())
  <section class="blog-section container pt-10 pb-10">
      <div class="title title-sm mt-8 title-center title-custom-underline mb-8 appear-animate">{{config('constant.constant.works.'.$lang)}}</div>
      <div class="owl-carousel owl-theme row cols-lg-3 cols-md-2 cols-1" data-owl-options="{
          'items': 3,
          'margin': 20,
          'loop': false,
          'nav': true,
          'dots': false,
          'responsive': {
              '0': {
                  'items': 1
              },
              '576': {
                  'items': 2
              },
              '992': {
                  'items': 3
              }
          }
      }">
      @foreach ($works as $key => $work)
        @include('parts.work')
      @endforeach

      </div>
  </section>
@endif
