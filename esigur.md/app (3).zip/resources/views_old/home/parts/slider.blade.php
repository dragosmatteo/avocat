@if ($sliders->count())
<div class="intro-slider animation-slider bg_main_1">

    @foreach ($sliders as $key => $slider)
    <div class="intro-slide1 banner banner-fixed">
        <figure>
            <picture>
                <source srcset="/files/sliders/lg/{{$slider->image.'.webp'}}" type="image/webp" media="(min-width: 1025px)">
                <source srcset="/files/sliders/lg/{{$slider->image.'.jpg'}}" type="image/jpeg" media="(min-width: 1025px)">
                <source srcset="/files/sliders/md/{{$slider->image.'.webp'}}" type="image/webp" media="(min-width: 415px)">
                <source srcset="/files/sliders/md/{{$slider->image.'.jpg'}}" type="image/jpeg" media="(min-width: 415px)">
                <source srcset="/files/sliders/sm/{{$slider->image.'.webp'}}" type="image/webp">
                <source srcset="/files/sliders/sm/{{$slider->image.'.jpg'}}" type="image/jpeg">
                <img width="1920" height="1080" loading="lazy" src="/files/sliders/lg/{{$slider->image.'.jpg'}}" data-src="/files/sliders/lg/{{$slider->image.'.jpg'}}" alt="{{$slider->name->$lang}}">
            </picture>
        </figure>
        <div class="container content-slider">
            <div class="banner-content y-50 text-left">
                @if ($slider->name->$lang)
                <h1 class="banner-title font-weight-bolder mb-4 btn-rounded slide-animate" data-animation-options="{'name': 'fadeInUp', 'duration': '.8s', 'delay': '.8s'}">
                    {{$slider->name->$lang}}
                </h1>
                @endif
                @if ($slider->title->$lang)
                <h2 class="banner-subtitle mb-8 slide-animate" data-animation-options="{'name': 'fadeInUp', 'duration': '1.2s', 'delay': '1.2s'}">
                    {{$slider->title->$lang}}
                </h2>
                @endif
                <a href="{{$slider->btn_link}}" class="btn btn-primary btn-filter text-uppercase slide-animate" data-animation-options="{'name': 'fadeInUp', 'duration': '1.2s', 'delay': '1.3s'}">{{$slider->btn_title->$lang}}</i></a>
            </div>
            <div class="request-form d-none d-lg-block appear-animate" data-animation-options="{
                        'delay': '.3s'
                    }">
                <div class="login-popup slider">
                    <div class="form-box">
                        <div class="tab tab-nav-simple tab-nav-boxed form-tab">
                            <ul class="nav nav-tabs nav-fill" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" href="#signin">{{config('constant.constant.action.'.$lang)}}</a>
                                </li>
                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane active" id="signin">
                                    <form action="{{ route('feedback.store') }}" method="post">
                                        <div class="form-group">
                                            <label>{{config('constant.constant.name.'.$lang)}}</label>
                                            <input type="text" class="form-control" name="name" required autocomplete="off"/>
                                        </div>
                                        <div class="form-group">
                                            <label>{{config('constant.constant.phone.'.$lang)}}</label>
                                            <input type="text" class="form-control" name="phone" required autocomplete="off"/>
                                        </div>
                                        @csrf
                                        <button class="btn btn-primary btn-block" type="submit">{{config('constant.constant.request.'.$lang)}}</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endforeach
</div>

<div class="bg_main_1 pb-5 pb-lg-0">
  <div class="container filter-tabs-wrapper appear-animate d-block d-lg-none" data-animation-options="{
              'delay': '.3s'
          }">
      <div class="mx-auto">
          <div class="tab tab-nav-simple tab-nav-center tab-nav-boxed">
              <ul class="nav nav-tabs" role="tablist">
                  <li class="nav-item">
                      <a class="nav-link active text-uppercase" href="#tab-filter-1">{{config('constant.constant.action.'.$lang)}}</a>
                  </li>
              </ul>
              <div class="action_sub text-center fs-30">
                  {{config('constant.constant.action_title.'.$lang)}}
              </div>
              <div class="tab-content">
                  <div class="tab-pane active in" id="tab-filter-1">
                      <form method="POST" action="{{route('feedback.store')}}">
                          <div class="toolbox-item mr-0 mr-lg-1 fixed">
                              <input class="form_name form-control" type="text" name="name" placeholder="{{config('constant.constant.name.'.$lang)}}" required="required" data-error="{{config('constant.constant.name_error.'.$lang)}}" autocomplete="off">
                          </div>
                          <div class="toolbox-item mr-0 mr-lg-1 fixed">
                              <input class="form_phone form-control" type="number" name="phone" placeholder="{{config('constant.constant.phone.'.$lang)}}" required="required" data-error="{{config('constant.constant.phone_error.'.$lang)}}"
                                autocomplete="off">
                          </div>
                          @csrf
                          <div class="toolbox-item mr-0 mr-lg-1 fixed">
                              <button class="btn btn-primary btn-filter text-uppercase">{{config('constant.constant.request.'.$lang)}}</button>
                          </div>
                      </form>
                  </div>
              </div>

          </div>
      </div>
  </div>
</div>

@endif
