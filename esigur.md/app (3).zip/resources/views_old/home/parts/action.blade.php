{{-- <section class="pt-10 pb-10">
  <div class="container">
    <div class="banner action banner-background parallax text-center" data-image-src="/files/abouts/lg/{{$about->image.'.jpg'}}">
        <div class="container">
            <div class="banner-content appear-animate"
                data-animation-options="{'name': 'blurIn', 'duration': '1s', 'delay': '.2s'}">
                <div class="banner-title font-weight-bold text-white">{{config('constant.constant.action.'.$lang)}}</div>
                <p class="text-white ls-s">{{config('constant.constant.action_title.'.$lang)}}</p>
                <div class="row d-flex justify-content-center">
                  <div class="col-lg-6 text-right">
                    <button class="btn btn-primary btn-rounded btn-icon-right call_modal">{{ config('constant.constant.request.'.$lang) }}</button>
                  </div>
                  <div class="col-lg-6 text-left">
                    <a title="{{$about->phone_1}}" href="tel:{{$about->phone_1}}" onclick="gtag_report_conversion()" class="btn btn-primary btn-rounded btn-icon-right">{{ config('constant.constant.contact_us.'.$lang) }}</a>
                  </div>
                </div>
            </div>
        </div>
    </div>
  </div>
</section> --}}

<section class="bg_main_1 pt-10 pb-10 mt-10">
  <div class="container w-100">
      <form method="POST" action="{{route('feedback.store')}}">
          <h4 style="margin-bottom: 20px!important" class="title title-sm title-center title-custom-underline mb-2 appear-animate">{{config('constant.constant.request.'.$lang)}}</h4>
          <br>
          <div class="row mb-2">
            <div class="col-md-6 mb-4">
                <input style="border-color: white; background: white; border-radius: 6px" class="form_name form-control" type="text" name="name" placeholder="{{config('constant.constant.name.'.$lang)}}" required="required" data-error="{{config('constant.constant.name_error.'.$lang)}}" autocomplete="off">
            </div>
            <div class="col-md-6 mb-4">
                <input style="border-color: white; background: white; border-radius: 6px" class="form_phone form-control" type="number" name="phone" placeholder="{{config('constant.constant.phone.'.$lang)}}" required="required" data-error="{{config('constant.constant.phone_error.'.$lang)}}" autocomplete="off">
            </div>
            <div class="col-12 mb-4">
                <textarea style="border-color: white; background: white; border-radius: 6px" class="form-control form_message" rows="4" name="message" placeholder="Комментарий"></textarea>
            </div>
          </div>
          @csrf
          <button class="btn btn-success btn-rounded newsletterbutton">{{config('constant.constant.send.'.$lang)}}</button>
      </form>
  </div>
</section>
