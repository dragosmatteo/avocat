<div class="appear-animate pt-10 pb-10 bg_main_1" data-animation-options="{
          'delay': '.3s'
      }">
    <section class="container banners-group pt-1">
        <div class="banner-group1">
            <div class="row">
                <div class="col-md-6 banner-desc-wrapper d-flex align-items-center mb-4 mb-lg-0">
                    <div class="banner-content pr-lg-10">
                        <div class="banner-title font-weight-bold ls-m pl-0 mb-1 appear-animate" data-animation-options="{'name': 'fadeInUpShorter', 'delay': '.3s'}">
                            {{$about->company}}
                        </div>
                        <h2 class="banner-subtitle mb-3 appear-animate" data-animation-options="{'name': 'fadeInUpShorter', 'delay': '.3s'}">{{$about->tagline->$lang}}</h2>
                        <p class="text-body mb-3 appear-animate" data-animation-options="{'name': 'fadeInUpShorter', 'delay': '.4s'}">
                          {!! Str::limit(strip_tags($about->body->$lang), 450) !!}
                        </p>
                        <a href="{{ route('service.index') }}" class="btn btn-primary btn-rounded  mb-1 appear-animate" data-animation-options="{'name': 'fadeInUpShorter', 'delay': '.6s'}">
                          {{config('constant.constant.services.'.$lang)}}
                        </a>
                        <a href="{{ route('about.index') }}" class="btn btn-primary btn-rounded  mb-1 appear-animate" data-animation-options="{'name': 'fadeInUpShorter', 'delay': '.6s'}">
                          {{config('constant.constant.about.'.$lang)}}
                        </a>
                    </div>
                </div>
                <div class="col-md-6 banner-images-wrapper">
                    <div class="row">

                        <div class="col-6 d-flex align-items-center">
                          @foreach ($about->images as $key => $image)
                            @if ($image and $loop->first)
                              <picture>
                                <source srcset="/files/abouts/lg/{{$image.'.webp'}}" type="image/webp" media="(min-width: 1025px)">
                                <source srcset="/files/abouts/lg/{{$image.'.jpg'}}" type="image/jpeg" media="(min-width: 1025px)">
                                <source srcset="/files/abouts/md/{{$image.'.webp'}}" type="image/webp" media="(min-width: 415px)">
                                <source srcset="/files/abouts/md/{{$image.'.jpg'}}" type="image/jpeg" media="(min-width: 415px)">
                                <source srcset="/files/abouts/sm/{{$image.'.webp'}}" type="image/webp">
                                <source srcset="/files/abouts/sm/{{$image.'.jpg'}}" type="image/jpeg">
                                <img loading="lazy" class="w-100 appear-animate" width="325" height="318" src="/files/abouts/lg/{{ $image.'.jpg' }}" data-src="/files/abouts/lg/{{ $image.'.jpg' }}" alt="{{$about->name->$lang}}">
                              </picture>
                            @endif
                          @endforeach
                        </div>

                        <div class="col-6">
                          @foreach ($about->images as $key => $image)
                            @if ($image and !$loop->first)
                                <div class="swiper-slide">
                                  <picture>
                                      <source srcset="/files/abouts/lg/{{$image.'.webp'}}" type="image/webp" media="(min-width: 1025px)">
                                      <source srcset="/files/abouts/lg/{{$image.'.jpg'}}" type="image/jpeg" media="(min-width: 1025px)">
                                      <source srcset="/files/abouts/md/{{$image.'.webp'}}" type="image/webp" media="(min-width: 415px)">
                                      <source srcset="/files/abouts/md/{{$image.'.jpg'}}" type="image/jpeg" media="(min-width: 415px)">
                                      <source srcset="/files/abouts/sm/{{$image.'.webp'}}" type="image/webp">
                                      <source srcset="/files/abouts/sm/{{$image.'.jpg'}}" type="image/jpeg">
                                      <img width="325" height="248" class="mb-4 d-block mx-auto appear-animate" src="/files/abouts/lg/{{$image.'.jpg'}}" alt="{{$about->name->$lang}}"  data-animation-options="{'name': 'fadeInUpShorter', 'delay': '.5s'}">
                                  </picture>
                              </div>
                            @endif
                          @endforeach
                            {{-- <img src="/assets/images/demos/demo33/banner/2.jpeg" alt="banner" width="325" height="248" class="mb-4 d-block mx-auto appear-animate" data-animation-options="{'name': 'fadeInUpShorter', 'delay': '.5s'}">
                            <img src="/assets/images/demos/demo33/banner/3.jpeg" alt="banner" width="325" height="248" class="d-block mx-auto appear-animate" data-animation-options="{'name': 'fadeInUpShorter', 'delay': '.6s'}"> --}}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
