@if ($blogs->count())
  <section class="blog container pt-10 pb-10 mb-10">
      <div class="title font-weight-bold lh-1 mb-5 appear-animate">{{config('constant.constant.blog.'.$lang)}}</div>
      <div class="owl-carousel owl-theme row cols-lg-3 cols-sm-2" data-owl-options="{
          'items': 1,
          'margin': 20,
          'loop': false,
          'nav' : true,
          'dots' : false,
          'responsive': {
              '576': {
                  'items': 2
              },
              '768': {
                  'items': 3
              }
          }
      }">
      @foreach ($blogs as $key => $blog)
        @include('parts.blog')
      @endforeach
      </div>
  </section>
@endif
