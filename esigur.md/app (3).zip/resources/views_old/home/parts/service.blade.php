@if ($services->count())
    <section class="pt-10 pb-10 appear-animate four-items" data-animation-options="{
        'delay': '.3s'
    }">
        <div class="container">
            <div class="title title-sm mt-8 title-center title-custom-underline mb-8 appear-animate">{{config('constant.constant.services.'.$lang)}}</div>
            <div class="owl-carousel owl-theme row cols-lg-4 cols-md-3 cols-sm-2 cols-1" data-owl-options="{
                'nav': true,
                'dots': false,
                'autoplay': false,
                'margin': 20,
                'loop': false,
                'responsive': {
                    '0': {
                        'margin': 0,
                        'items': 1
                    },
                    '576': {
                        'items': 1
                    },
                    '768': {
                        'items': 2
                    },
                    '992': {
                        'items': 3
                    }
                }
            }">
            @foreach ($services as $key => $service)
              @include('parts.service', $service)
            @endforeach
          </div>
        </div>
    </section>
@endif
