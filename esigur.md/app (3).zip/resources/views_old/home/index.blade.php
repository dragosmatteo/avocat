@extends('app.master')

@section('meta')
<title>{{ config('constant.constant.home_seo_title.'.$lang) }}</title>
<meta name="description" content="{{ config('constant.constant.home_seo_desc.'.$lang) }}"/>

{{-- <meta property="fb:app_id" content="1355208687908995" /> --}}
<meta property="og:type"   content="website" />
<meta property="og:url"    content="{{url()->current()}}" />
<meta property="og:image"    content="https://casadevis.md/assets/img/casadevis_{{ $lang }}.jpg" />
<meta property="og:title"  content="{{ config('constant.constant.home_seo_title.'.$lang) }}" />
<meta property="og:description"  content="{{ config('constant.constant.home_seo_desc.'.$lang) }}" />

<!-- Event snippet for Просмотр страницы conversion page -->
<script>
  gtag('event', 'conversion', {
      'send_to': 'AW-319809177/9bijCIKr5uYCEJnNv5gB',
      'value': 1.0,
      'currency': 'USD'
  });
</script>
@endsection

@section('content')
  @include('home.parts.slider')
  @include('home.parts.service')
  @include('home.parts.about')
  @include('home.parts.features')
  @include('home.parts.testimonials')
  @include('home.parts.work')
  {{-- @include('home.parts.blog') --}}
  @include('home.parts.action')
@endsection
