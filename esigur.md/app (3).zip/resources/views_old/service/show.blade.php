@extends('app.master')

@section('meta')
@if (isset($service->name_seo->$lang))
<title>{{ $service->name_seo->$lang }}</title>
@else
<title>{{ $service->name->$lang }}. {{ $about->name->$lang }}</title>
@endif

<meta name="description" content="{{ $service->title->$lang }}" />

{{-- <meta property="fb:app_id" content="1355208687908995" /> --}}
<meta property="og:type" content="website" />
<meta property="og:url" content="{{url()->current()}}" />
<meta property="og:image" content="https://casadevis.md/assets/img/casadevis_{{ $lang }}.jpg" />
<meta property="og:title" content="{{ (isset($service->name_seo->$lang))? $service->name_seo->$lang : $service->name->$lang.'. '.$about->name->$lang }}" />
<meta property="og:description" content="{{ $service->title->$lang }}" />

<script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        "itemListElement": [{
            "@type": "ListItem",
            "position": 1,
            "name": "{{config('constant.constant.main.'.$lang)}}",
            "item": "{{route('home')}}"
        }, {
            "@type": "ListItem",
            "position": 2,
            "name": "{{config('constant.constant.services.'.$lang)}}",
            "item": "{{route('service.index')}}"
        }, {
            "@type": "ListItem",
            "position": 3,
            "name": "{{ $service->name->$lang }}"
        }]
    }
</script>

<!-- Event snippet for Просмотр страницы conversion page -->
<script>
  gtag('event', 'conversion', {
      'send_to': 'AW-319809177/9bijCIKr5uYCEJnNv5gB',
      'value': 2.0,
      'currency': 'USD'
  });
</script>
@endsection

@section('header')
<div class="product-navigation bg_main_2">
    <div class="container">
        <ul class="breadcrumb breadcrumb-lg">
            <li><a href="{{route('home')}}"><i class="d-icon-home"></i></a></li>
            <li><a href="{{route('service.index')}}">{{config('constant.constant.services.'.$lang)}}</a></li>
            <li>{{$service->name->$lang}}</li>
        </ul>
    </div>
</div>
@endsection

@section('content')
<div class="page-content bg_main_1 pt-5 pb-10">
    <div class="container">
        <div class="product product-single row">
            <div class="col-md-12 order-1 order-lg-2">
                <div class="product-details pl-0">
                    <h1 class="product-name">{{$service->name->$lang}}</h1>
                </div>
                <div class="card border-no card-description bg_main_1">
                    <div class="card-body expanded">
                        <div class="row">
                            <div class="col-12">
                                {!! $service->body->$lang !!}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@if ($service->services->count())
<section class="mt-10 appear-animate four-items" data-animation-options="{
        'delay': '.3s'
    }">
    <div class="container">
        <div class="owl-carousel owl-theme row cols-lg-4 cols-md-3 cols-sm-2 cols-1" data-owl-options="{
                'nav': true,
                'loop': false,
                'dots': false,
                'autoplay': false,
                'margin': 20,
                'responsive': {
                    '0': {
                        'margin': 0,
                        'items': 1
                    },
                    '576': {
                        'items': 1
                    },
                    '768': {
                        'items': 2
                    },
                    '992': {
                        'items': 3
                    }
                }
            }">

            @foreach ($service->services as $key => $ser)
              @include('parts.subservice')
            @endforeach

        </div>
    </div>
</section>
@else
  @if ($service->service->services->where('id','!=', $service->id)->count())
    <section class="mt-10 pb-10 appear-animate four-items" data-animation-options="{
            'delay': '.3s'
        }">
        <div class="container">
            <div class="owl-carousel owl-theme row cols-lg-4 cols-md-3 cols-sm-2 cols-1" data-owl-options="{
                    'nav': true,
                    'loop': false,
                    'dots': false,
                    'autoplay': false,
                    'margin': 20,
                    'responsive': {
                        '0': {
                            'items': 2
                        },
                        '576': {
                            'items': 2
                        },
                        '768': {
                            'items': 2
                        },
                        '992': {
                            'items': 4
                        }
                    }
                }">

                @foreach ($service->service->services->where('id','!=', $service->id) as $key => $ser)
                  @include('parts.subservice',['service' => $service->service])
                @endforeach

            </div>
        </div>
    </section>
  @endif
@endif

<section class="bg_main_1 pt-10 pb-10 mt-10">
  <div class="container w-100">
      <form method="POST" action="{{route('feedback.store')}}">
          <h4 style="margin-bottom: 0px!important" class="title title-sm title-left title-custom-underline mb-2 appear-animate">{{config('constant.constant.request.'.$lang)}}</h4>
          <br>
          <div class="row mb-2">
            <div class="col-md-6 mb-4">
                <input style="border-color: white; background: white; border-radius: 6px" class="form_name form-control" type="text" name="name" placeholder="{{config('constant.constant.name.'.$lang)}}" required="required" data-error="{{config('constant.constant.name_error.'.$lang)}}" autocomplete="off">
            </div>
            <div class="col-md-6 mb-4">
                <input style="border-color: white; background: white; border-radius: 6px" class="form_phone form-control" type="number" name="phone" placeholder="{{config('constant.constant.phone.'.$lang)}}" required="required" data-error="{{config('constant.constant.phone_error.'.$lang)}}" autocomplete="off">
            </div>
            <div class="col-12 mb-4">
                <textarea style="border-color: white; background: white; border-radius: 6px" class="form-control form_message" rows="4" name="message" placeholder="Комментарий"></textarea>
            </div>
          </div>
          @csrf
          <button class="btn btn-success btn-rounded newsletterbutton">{{config('constant.constant.send.'.$lang)}}</button>
      </form>
  </div>
</section>

@if ($service->works->count())
<section class="blog-section container pt-10 pb-10 mt-10">
    <div class="title font-weight-bold lh-1 mb-5 appear-animate">{{$service->work_title->$lang}}</div>
    <div class="owl-carousel owl-theme row cols-lg-3 cols-md-2 cols-1" data-owl-options="{
          'items': 3,
          'margin': 20,
          'loop': false,
          'nav': true,
          'dots': false,
          'responsive': {
              '0': {
                  'items': 1
              },
              '576': {
                  'items': 2
              },
              '992': {
                  'items': 3
              }
          }
      }">
        @foreach ($service->works as $key => $work)
        @include('parts.work')
        @endforeach
    </div>
</section>
@endif

@if ($service->advantages->count())
<section class="mt-10 pb-10 pt-10 service-list-section p-relative overflow-hidden">
    <div class="container">
        <div class="title-wrapper text-center">
            <div class="title font-weight-bold lh-1 mb-5 appear-animate">
                {{$service->advantage_title->$lang}}
            </div>
        </div>
        <div class="service-list service-list-lg appear-animate" data-animation-options="{
              'name': 'fadeInUpShorter',
              'delay': '.2s'
          }">
            <div class="row show-shadow">
                @foreach ($service->advantages as $key => $val)
                  @include('parts.advantage')
                @endforeach
            </div>
        </div>
    </div>
</section>
@endif

@if ($service->faqs->count())
<div class="page-content mb-10 mt-10" itemscope itemtype="https://schema.org/FAQPage">
    <div class="container">
        <div class="title-wrapper text-center">
            <div class="title font-weight-bold lh-1 mb-5 appear-animate">
                {{$service->faq_title->$lang}}
            </div>
        </div>
        <div class="product product-single row">
            <div class="col-md-12 order-1 order-lg-2">
                <div class="accordion accordion-simple mb-4">
                    @foreach ($service->faqs as $key => $faq)
                      <div class="card card-additional" itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
                          <div class="card-header">
                              <a href="#collapse1-{{$key}}" class="expand">
                                <span itemprop="name">{{$faq->name->$lang}}</span>
                              </a>
                          </div>
                          <div class="card-body collapsed" id="collapse1-{{$key}}" itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
                              <div itemprop="text">
                                  {!! $faq->body->$lang !!}
                              </div>
                          </div>
                      </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</div>
@endif

@endsection
