@extends('app.master')

@section('meta')
@if (isset($subservice->name_seo->$lang))
<title>{{ $subservice->name_seo->$lang }}</title>
@else
<title>{{$service->name->$lang}} - {{$subservice->name->$lang}}</title>
@endif
<meta name="description" content="{{ $subservice->title->$lang }}" />

{{-- <meta property="fb:app_id" content="1355208687908995" /> --}}
<meta property="og:type" content="website" />
<meta property="og:url" content="{{url()->current()}}" />
<meta property="og:image" content="https://casadevis.md/assets/img/casadevis_{{ $lang }}.jpg" />
<meta property="og:title" content="{{(isset($subservice->name_seo->$lang))? $subservice->name_seo->$lang : $service->name->$lang}} - {{$subservice->name->$lang}}" />
<meta property="og:description" content="{{ $subservice->title->$lang }}" />

<script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        "itemListElement": [{
            "@type": "ListItem",
            "position": 1,
            "name": "{{config('constant.constant.services.'.$lang)}}",
            "item": "{{route('service.index')}}"
        }, {
            "@type": "ListItem",
            "position": 2,
            "name": "{{ $service->name->$lang }}",
            "item": "{{route('service.show', $service)}}"
        }, {
            "@type": "ListItem",
            "position": 3,
            "name": "{{ $subservice->name->$lang }}"
        }]
    }
</script>

<!-- Event snippet for Просмотр страницы conversion page -->
<script>
  gtag('event', 'conversion', {
      'send_to': 'AW-319809177/9bijCIKr5uYCEJnNv5gB',
      'value': 3.0,
      'currency': 'USD'
  });
</script>
@endsection

@section('header')
<div class="product-navigation bg_main_2">
    <div class="container">
        <ul class="breadcrumb breadcrumb-lg">
            <li><a href="{{route('home')}}"><i class="d-icon-home"></i></a></li>
            <li><a href="{{route('service.index')}}">{{config('constant.constant.services.'.$lang)}}</a></li>
            <li><a href="{{route('service.show', $service)}}">{{$service->name->$lang}}</a></li>
            <li>{{$subservice->name->$lang}}</li>
        </ul>
    </div>
</div>
@endsection

@section('content')

<div class="page-content pt-10 pb-10 bg_main_1">
    <div class="container">
        <div class="product product-single row">

            <div class="col-md-12 order-1 order-lg-2">
                <div class="product-details pl-0">
                    <h1 class="product-name">{{$subservice->name->$lang}}</h1>
                </div>

                <div class="card border-no card-description bg_main_1">
                    <div class="card-body expanded">
                        <div class="row">
                            <div class="col-12">
                                {!! $subservice->body->$lang !!}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@if ($similars->count())
<section class="mt-10 appear-animate four-items" data-animation-options="{
        'delay': '.3s'
    }">
    <div class="container">
        <div class="owl-carousel owl-theme row cols-lg-4 cols-md-3 cols-sm-2 cols-1" data-owl-options="{
                'nav': true,
                'loop': false,
                'dots': false,
                'autoplay': false,
                'margin': 20,
                'responsive': {
                    '0': {
                        'margin': 0,
                        'items': 1
                    },
                    '576': {
                        'items': 1
                    },
                    '768': {
                        'items': 2
                    },
                    '992': {
                        'items': 3
                    }
                }
            }">

            @include('parts.service', $service)

            @foreach ($similars as $key => $ser)
            @include('parts.subservice')
            @endforeach

        </div>
    </div>
</section>
@endif

<section class="bg_main_1 pt-10 pb-10 mt-10">
  <div class="container w-100">
      <form method="POST" action="{{route('feedback.store')}}">
          <h4 style="margin-bottom: 0px!important" class="title title-sm title-left title-custom-underline mb-2 appear-animate">{{config('constant.constant.request.'.$lang)}}</h4>
          <br>
          <div class="row mb-2">
            <div class="col-md-6 mb-4">
                <input style="border-color: white; background: white; border-radius: 6px" class="form_name form-control" type="text" name="name" placeholder="{{config('constant.constant.name.'.$lang)}}" required="required" data-error="{{config('constant.constant.name_error.'.$lang)}}" autocomplete="off">
            </div>
            <div class="col-md-6 mb-4">
                <input style="border-color: white; background: white; border-radius: 6px" class="form_phone form-control" type="number" name="phone" placeholder="{{config('constant.constant.phone.'.$lang)}}" required="required" data-error="{{config('constant.constant.phone_error.'.$lang)}}" autocomplete="off">
            </div>
            <div class="col-12 mb-4">
                <textarea style="border-color: white; background: white; border-radius: 6px" class="form-control form_message" rows="4" name="message" placeholder="Комментарий"></textarea>
            </div>
          </div>
          @csrf
          <button class="btn btn-success btn-rounded newsletterbutton">{{config('constant.constant.send.'.$lang)}}</button>
      </form>
  </div>
</section>

@if ($subservice->advantages->count())
<section class="mt-10 pb-10 pt-10 service-list-section p-relative overflow-hidden">
    <div class="container">
        <div class="title-wrapper text-center">
            <div class="title font-weight-bold lh-1 mb-5 appear-animate">
                {{$subservice->advantage_title->$lang}}
            </div>
        </div>
        <div class="service-list service-list-lg appear-animate" data-animation-options="{
              'name': 'fadeInUpShorter',
              'delay': '.2s'
          }">
            <div class="row show-shadow">
                @foreach ($subservice->advantages as $key => $val)
                @include('parts.advantage')
                @endforeach
            </div>
        </div>
    </div>
</section>
@endif

@if ($subservice->parts->count())
<section class="pb-10 pt-10 service-list-section p-relative overflow-hidden">
    <div class="container">
        <div class="title-wrapper text-center">
            <div class="title font-weight-bold lh-1 mb-5 appear-animate">
                {{(isset($subservice->subname->$lang))? $subservice->subname->$lang : ''}}
            </div>
        </div>
        <div class="service-list service-list-lg appear-animate" data-animation-options="{
              'name': 'fadeInUpShorter',
              'delay': '.2s'
          }">
            <div class="row show-shadow">
                @foreach ($subservice->parts as $key => $val)
                @include('parts.subservice_info')
                @endforeach
            </div>
        </div>
    </div>
</section>
@endif

@if ($subservice->steps->count())
<section class="pb-10 pt-10 mt-10 service-list-section p-relative overflow-hidden bg_main_1">
    <div class="container">
        <div class="title-wrapper text-center">
            <h2 class="title font-weight-bold lh-1 mb-5 appear-animate">
                {{$subservice->step_title->$lang}}
            </h2>
        </div>
        <div class="service-list full service-list-lg appear-animate" data-animation-options="{
              'name': 'fadeInUpShorter',
              'delay': '.2s'
          }">
            <div class="row show-shadow">
                @foreach ($subservice->steps as $key => $val)
                @include('parts.step')
                @endforeach
            </div>
        </div>
    </div>
</section>
@endif

@if ($subservice->works->count())
<section class="blog-section container pt-10 pb-10">
    <div class="title font-weight-bold lh-1 mb-5 appear-animate">{{$subservice->work_title->$lang}}</div>
    <div class="owl-carousel owl-theme row cols-lg-3 cols-md-2 cols-1" data-owl-options="{
          'items': 3,
          'margin': 20,
          'loop': false,
          'nav': true,
          'dots': false,
          'responsive': {
              '0': {
                  'items': 1
              },
              '576': {
                  'items': 2
              },
              '992': {
                  'items': 3
              }
          }
      }">
        @foreach ($subservice->works as $key => $work)
        @include('parts.work')
        @endforeach
    </div>
</section>
@endif

@if ($subservice->faqs->count())
<div class="page-content mb-10 mt-10" itemscope itemtype="https://schema.org/FAQPage">
    <div class="container">
        <div class="title-wrapper text-center">
            <div class="title font-weight-bold lh-1 mb-5 appear-animate">
                {{$subservice->faq_title->$lang}}
            </div>
        </div>
        <div class="product product-single row">
            <div class="col-md-12 order-1 order-lg-2">
                <div class="accordion accordion-simple mb-4">
                    @foreach ($subservice->faqs as $key => $faq)
                      <div class="card card-additional" itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
                          <div class="card-header">
                              <a href="#collapse1-{{$key}}" class="expand">
                                <span itemprop="name">{{$faq->name->$lang}}</span>
                              </a>
                          </div>
                          <div class="card-body collapsed" id="collapse1-{{$key}}" itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
                              <div itemprop="text">
                                  {!! $faq->body->$lang !!}
                              </div>
                          </div>
                      </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</div>
@endif

@endsection
