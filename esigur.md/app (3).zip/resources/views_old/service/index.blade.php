@extends('app.master')

@section('meta')
<title>{{config('constant.constant.service_seo_title.'.$lang)}}</title>
<meta name="description" content="{{config('constant.constant.service_seo_desc.'.$lang)}}"/>

{{-- <meta property="fb:app_id" content="1355208687908995" /> --}}
<meta property="og:type"   content="website" />
<meta property="og:url"    content="{{url()->current()}}" />
<meta property="og:image"    content="https://casadevis.md/assets/img/casadevis_{{ $lang }}.jpg" />
<meta property="og:title"  content="{{config('constant.constant.service_seo_title.'.$lang)}}" />
<meta property="og:description"  content="{{config('constant.constant.service_seo_desc.'.$lang)}}" />
@endsection

@section('header')
<nav class="breadcrumb-nav">
    <div class="container">
        <ul class="breadcrumb">
            <li><a href="{{route('home')}}"><i class="d-icon-home"></i></a></li>
            <li>{{config('constant.constant.services.'.$lang)}}</li>
        </ul>
    </div>
</nav>
@endsection

@section('content')
  {{-- @if ($services->count())
    <section class="pt-10 pb-10 appear-animate four-items" data-animation-options="{
        'delay': '.3s'
    }">
        <div class="container">
            <div class="row">
              @foreach ($services as $key => $service)
                <div class="mb-2 mt-2 col-lg-3 col-6">
                  @include('parts.service')
                </div>
              @endforeach
            </div>
        </div>
    </section>
  @endif --}}

  @if ($services->count())
    @foreach ($services->where('service_id', null) as $key => $service)
      <section class="pt-10 pb-10 appear-animate four-items" data-animation-options="{
          'delay': '.3s'
      }">
          <div class="container">
              <div class="title title-sm mt-8 title-left title-custom-underline mb-8 appear-animate">{{ $service->name->$lang }}</div>
              <div class="owl-carousel owl-theme row cols-lg-4 cols-md-3 cols-sm-2 cols-1" data-owl-options="{
                  'nav': true,
                  'dots': false,
                  'autoplay': false,
                  'margin': 20,
                  'loop': false,
                  'responsive': {
                      '0': {
                          'margin': 0,
                          'items': 1
                      },
                      '576': {
                          'items': 1
                      },
                      '768': {
                          'items': 2
                      },
                      '992': {
                          'items': 3
                      }
                  }
              }">

              @include('parts.service', $service)
              @foreach ($service->services as $key => $ser)
                  @include('parts.subservice', $ser)
              @endforeach
            </div>
          </div>
      </section>
      @endforeach
  @endif


@include('home.parts.action')
@endsection
