@extends('app.master')

@section('meta')
<title>{{config('constant.constant.about_seo_title.'.$lang)}}</title>
<meta name="description" content="{{config('constant.constant.about_seo_desc.'.$lang)}}"/>

{{-- <meta property="fb:app_id" content="1355208687908995" /> --}}
<meta property="og:type"   content="website" />
<meta property="og:url"    content="{{url()->current()}}" />
<meta property="og:image"    content="https://casadevis.md/assets/img/casadevis_{{ $lang }}.jpg" />
<meta property="og:title"  content="{{config('constant.constant.about_seo_title.'.$lang)}}" />
<meta property="og:description"  content="{{config('constant.constant.about_seo_desc.'.$lang)}}" />

<script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [{
        "@type": "ListItem",
        "position": 1,
        "name": "{{config('constant.constant.main.'.$lang)}}",
        "item": "{{route('home')}}"
      },{
        "@type": "ListItem",
        "position": 2,
        "name": "{{config('constant.constant.about.'.$lang)}}"
      }]
    }
</script>
@endsection

@section('header')
  <nav class="breadcrumb-nav">
      <div class="container">
          <ul class="breadcrumb">
              <li><a href="{{route('home')}}"><i class="d-icon-home"></i></a></li>
              <li>{{config('constant.constant.about.'.$lang)}}</li>
          </ul>
      </div>
  </nav>
@endsection

@section('content')
  @if (isset($about))
    <div class="container appear-animate pt-10 " data-animation-options="{
              'delay': '.3s'
          }">
        <section class="banners-group">
            <div class="banner-group1">
                <div class="row">
                    <div class="col-md-6 banner-desc-wrapper w-100 d-flex align-items-center mb-4 mb-lg-0">
                        <div class="banner-content">
                            <h1 style="margin-bottom: 15px!important" class="title title-sm mt-8 title-center title-custom-underline appear-animate" data-animation-options="{'name': 'fadeInUpShorter', 'delay': '.3s'}">
                                {{$about->company}}
                            </h1>
                            <h2 class="banner-subtitle text-center mb-10 appear-animate" data-animation-options="{'name': 'fadeInUpShorter', 'delay': '.3s'}">{{$about->tagline->$lang}}</h2>
                            <div class="row">
                                @foreach ($about->images as $key => $image)
                                  <div class="col-4">
                                      @if ($image)
                                          <div class="swiper-slide">
                                            <picture>
                                                <source srcset="/files/abouts/lg/{{$image.'.webp'}}" type="image/webp" media="(min-width: 1025px)">
                                                <source srcset="/files/abouts/lg/{{$image.'.jpg'}}" type="image/jpeg" media="(min-width: 1025px)">
                                                <source srcset="/files/abouts/md/{{$image.'.webp'}}" type="image/webp" media="(min-width: 415px)">
                                                <source srcset="/files/abouts/md/{{$image.'.jpg'}}" type="image/jpeg" media="(min-width: 415px)">
                                                <source srcset="/files/abouts/sm/{{$image.'.webp'}}" type="image/webp">
                                                <source srcset="/files/abouts/sm/{{$image.'.jpg'}}" type="image/jpeg">
                                                <img width="325" height="248" class="mb-4 d-block w-100 appear-animate rounded" src="/files/abouts/lg/{{$image.'.jpg'}}" alt="{{$about->name->$lang}}"  data-animation-options="{'name': 'fadeInUpShorter', 'delay': '.5s'}">
                                            </picture>
                                        </div>
                                      @endif
                                  </div>
                                @endforeach
                            </div>
                            <p class="text-body mb-5 appear-animate" data-animation-options="{'name': 'fadeInUpShorter', 'delay': '.4s'}">
                              {!! $about->body->$lang !!}
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
  @endif

  @include('home.parts.testimonials')

  <section class="bg_main_1 pt-10 pb-10 mt-10">
    <div class="container w-100">
        <form method="POST" action="{{route('feedback.store')}}">
            <h4 style="margin-bottom: 20px!important" class="title title-sm title-center title-custom-underline mb-2 appear-animate">{{config('constant.constant.request.'.$lang)}}</h4>
            <br>
            <div class="row mb-2">
              <div class="col-md-6 mb-4">
                  <input style="border-color: white; background: white; border-radius: 6px" class="form_name form-control" type="text" name="name" placeholder="{{config('constant.constant.name.'.$lang)}}" required="required" data-error="{{config('constant.constant.name_error.'.$lang)}}" autocomplete="off">
              </div>
              <div class="col-md-6 mb-4">
                  <input style="border-color: white; background: white; border-radius: 6px" class="form_phone form-control" type="number" name="phone" placeholder="{{config('constant.constant.phone.'.$lang)}}" required="required" data-error="{{config('constant.constant.phone_error.'.$lang)}}" autocomplete="off">
              </div>
              <div class="col-12 mb-4">
                  <textarea style="border-color: white; background: white; border-radius: 6px" class="form-control form_message" rows="4" name="message" placeholder="Комментарий"></textarea>
              </div>
            </div>
            @csrf
            <button class="btn btn-success btn-rounded newsletterbutton">{{config('constant.constant.send.'.$lang)}}</button>
        </form>
    </div>
  </section>

  <div class="grey-section google-map" id="googlemaps">
    {!! $about->map !!}
  </div>

@endsection
