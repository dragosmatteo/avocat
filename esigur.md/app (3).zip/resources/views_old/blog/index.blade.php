@extends('app.master')

@section('meta')
<title>{{ (isset($type))? $type->title->$lang : config('constant.constant.blog_seo_title.'.$lang) }}</title>
<meta name="description" content="{{ (isset($type))? $type->body->$lang : config('constant.constant.blog_seo_desc.'.$lang) }}" />

{{-- <meta property="fb:app_id" content="1355208687908995" /> --}}
<meta property="og:type" content="website" />
<meta property="og:url" content="{{url()->current()}}" />
<meta property="og:image" content="https://casadevis.md/assets/img/casadevis_{{ $lang }}.jpg" />
<meta property="og:title" content="{{ (isset($type))? $type->title->$lang : config('constant.constant.blog_seo_title.'.$lang) }}" />
<meta property="og:description" content="{{ (isset($type))? $type->body->$lang : config('constant.constant.blog_seo_desc.'.$lang) }}" />

<script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        "itemListElement": [{
            "@type": "ListItem",
            "position": 1,
            "name": "{{config('constant.constant.main.'.$lang)}}",
            "item": "{{route('home')}}"
        }, {
            "@type": "ListItem",
            "position": 2,
            "name": "{{config('constant.constant.blog.'.$lang)}}"
        }]
    }
</script>
@endsection

@section('header')
<nav class="breadcrumb-nav">
    <div class="container">
        <ul class="breadcrumb">
            <li><a href="{{route('home')}}"><i class="d-icon-home"></i></a></li>
            <li>{{(isset($type))? $type->name->$lang : config('constant.constant.blog.'.$lang)}}</li>
        </ul>
    </div>
</nav>
@endsection

@section('content')
@if ($types->count())
  <div class="container">
      <ul class="nav-filters filter-underline blog-filters justify-content-start mb-4">
        @foreach ($types as $key => $type)
          @if ($type->blogs->count())
            <li class="ml-0 mr-5">
              <a href="{{route('type.blogs', $type)}}" class="nav-filter {{(url()->current() == route('type.blogs', $type))? 'active' : ''}}" data-filter="*">
                {{$type->name->$lang}}
              </a>
            </li>
          @endif
        @endforeach
      </ul>
  </div>
@endif


<div class="page-content pt-5 pb-10">
    <div class="container">
        <div class="posts grid post-grid row d-flex" data-grid-options="{
              'layoutMode': 'fitRows'
          }">
            @foreach ($blogs as $key => $blog)
            <div class="col-sm-6 col-lg-4 grid-item lifestyle shopping winter-sale">
                @include('parts.blog')
            </div>
            @endforeach
        </div>
    </div>
</div>

@include('home.parts.action')

@endsection
