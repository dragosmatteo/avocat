@extends('app.master')

@section('meta')
<title>{{ $blog->seo_name->$lang }}</title>
<meta name="description" content="{{ $blog->title->$lang }}"/>

{{-- <meta property="fb:app_id" content="1355208687908995" /> --}}
<meta property="og:type"   content="website" />
<meta property="og:url"    content="{{url()->current()}}" />
<meta property="og:image"    content="https://casadevis.md/assets/img/casadevis_{{ $lang }}.jpg" />
<meta property="og:title"  content="{{ $blog->seo_name->$lang }}" />
<meta property="og:description"  content="{{ $blog->title->$lang }}" />

<script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "NewsArticle",
      "mainEntityOfPage": {
        "@type": "WebPage",
        "@id": "{{ url()->current() }}"
      },
      "headline": "{{ $blog->name->$lang }}",
      "image": [
        "https://webcraft.md/files/blogs/lg/{{$blog->image}}.jpg"
       ],
      "datePublished": "{{$blog->created_at->format('d M Y')}}",
      "dateModified": "{{$blog->created_at->format('d M Y')}}",
      "author": {
        "@type": "Person",
        "name": "Tofan Stanislav"
      },
       "publisher": {
        "@type": "Organization",
        "name": "Webcraft",
        "logo": {
          "@type": "ImageObject",
          "url": "https://webcraft.md/files/{{$about->logo}}"
        }
      }
    }
</script>

<script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [{
        "@type": "ListItem",
        "position": 1,
        "name": "{{config('constant.constant.main.'.$lang)}}",
        "item": "{{route('home')}}"
      },{
        "@type": "ListItem",
        "position": 2,
        "name": "{{config('constant.constant.blog.'.$lang)}}",
        "item": "{{route('blog.index')}}"
      },{
        "@type": "ListItem",
        "position": 3,
        "name": "{{ $blog->name->$lang }}"
      }]
    }
</script>
@endsection

@section('header')
  <nav class="breadcrumb-nav mt-0 mt-lg-3">
      <div class="container">
          <ul class="breadcrumb">
              <li><a href="{{route('home')}}"><i class="d-icon-home"></i></a></li>
              <li><a href="{{ route('blogs.index') }}" class="active">{{config('constant.constant.blog.'.$lang)}}</a></li>
              <li>{{ $blog->name->$lang }}</li>
          </ul>
      </div>
  </nav>
@endsection

@section('content')
  <div class="page-content with-sidebar pt-5">
      <div class="container">
          <div class="row gutter-lg">
              <div class="col-lg-12">

                  <article class="post-single">
                      <figure class="post-media">
                        <picture>
                          <source srcset="/files/blogs/lg/{{$blog->image.'.webp'}}" type="image/webp" media="(min-width: 1025px)">
                          <source srcset="/files/blogs/lg/{{$blog->image.'.jpg'}}" type="image/jpeg" media="(min-width: 1025px)">
                          <source srcset="/files/blogs/md/{{$blog->image.'.webp'}}" type="image/webp" media="(min-width: 415px)">
                          <source srcset="/files/blogs/md/{{$blog->image.'.jpg'}}" type="image/jpeg" media="(min-width: 415px)">
                          <source srcset="/files/blogs/sm/{{$blog->image.'.webp'}}" type="image/webp">
                          <source srcset="/files/blogs/sm/{{$blog->image.'.jpg'}}" type="image/jpeg">
                          <img loading="lazy" id="dsn-hero-parallax-img" class="w-100 has-top-bottom lazyload" data-src="/files/blogs/lg/{{ $blog->image.'.webp' }}" alt="{{ $blog->name->$lang }}" data-dsn-header="blog" data-dsn-ajax="img">
                        </picture>
                      </figure>
                      <div class="post-details">
                          <h4 class="post-title">{{ $blog->name->$lang }}</h4>
                          <div class="post-body mb-7">
                              {!! $blog->body->$lang !!}
                          </div>
                      </div>
                  </article>

                  @if ($blogs->count())
                    <div class="related-posts">
                        <h3 class="title title-simple text-left text-normal font-weight-bold ls-normal">{{config('constant.constant.similars.'.$lang)}}</h3>
                        <div class="owl-carousel owl-theme row cols-lg-3 cols-sm-2" data-owl-options="{
                            'items': 1,
                            'margin': 20,
                            'loop': false,
                            'nav' : true,
                            'dots' : false,
                            'responsive': {
                                '576': {
                                    'items': 2
                                },
                                '768': {
                                    'items': 3
                                }
                            }
                        }">
                        @foreach ($blogs as $key => $blog)
                          @include('parts.blog')
                        @endforeach
                        </div>
                    </div>
                  @endif

              </div>
          </div>
      </div>
  </div>

  @include('home.parts.action')

@endsection
