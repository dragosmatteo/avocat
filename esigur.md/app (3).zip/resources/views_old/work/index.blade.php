@extends('app.master')

@section('meta')
<title>{{ (isset($type))? $type->title->$lang : config('constant.constant.work_seo_title.'.$lang) }}</title>
<meta name="description" content="{{ (isset($type))? $type->body->$lang : config('constant.constant.work_seo_desc.'.$lang) }}"/>

{{-- <meta property="fb:app_id" content="1355208687908995" /> --}}
<meta property="og:type"   content="website" />
<meta property="og:url"    content="{{url()->current()}}" />
<meta property="og:image"    content="https://casadevis.md/assets/img/casadevis_{{ $lang }}.jpg" />
<meta property="og:title"  content="{{ (isset($type))? $type->title->$lang : config('constant.constant.work_seo_title.'.$lang) }}" />
<meta property="og:description"  content="{{ (isset($type))? $type->body->$lang : config('constant.constant.work_seo_desc.'.$lang) }}" />

<script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [{
        "@type": "ListItem",
        "position": 1,
        "name": "{{config('constant.constant.main.'.$lang)}}",
        "item": "{{route('home')}}"
      },{
        "@type": "ListItem",
        "position": 2,
        "name": "{{config('constant.constant.works.'.$lang)}}"
      }]
    }
</script>
@endsection

@section('header')
  @if (isset($type))
    <nav class="breadcrumb-nav">
        <div class="container">
            <ul class="breadcrumb">
                <li><a href="{{route('home')}}"><i class="d-icon-home"></i></a></li>
                <li><a href="{{route('work.index')}}">{{config('constant.constant.works.'.$lang)}}</a></li>
                <li>{{ $type->name->$lang }}</li>
            </ul>
        </div>
    </nav>
  @else
    <nav class="breadcrumb-nav">
        <div class="container">
            <ul class="breadcrumb">
                <li><a href="{{route('home')}}"><i class="d-icon-home"></i></a></li>
                <li>{{config('constant.constant.works.'.$lang)}}</li>
            </ul>
        </div>
    </nav>
  @endif

@endsection

@section('content')
  @if (isset($type))
    <div class="page-content pt-10 pb-10">
        <div class="container">
            <div class="posts grid post-grid row" data-grid-options="{
                'layoutMode': 'fitRows'
            }">
            @foreach ($works as $key => $work)
              <div class="grid-item col-sm-6 col-lg-4 lifestyle shopping winter-sale">
                @include('parts.work')
              </div>
            @endforeach
            </div>
        </div>
    </div>
    @else
    @foreach ($app_types as $key => $type)
      @if ($type->works->count())
        <div class="page-content pt-10 pb-10">
            <div class="container">
                {{-- <div class="title font-weight-bold lh-1 mb-3 appear-animate">{{ $type->name->$lang }}</div> --}}
                <div class="posts grid post-grid row" data-grid-options="{
                    'layoutMode': 'fitRows'
                }">
                @foreach ($type->works as $key => $work)
                  <div class="grid-item col-sm-6 col-lg-4 lifestyle shopping winter-sale">
                    @include('parts.work')
                  </div>
                @endforeach
                </div>
            </div>
        </div>
      @endif
    @endforeach
  @endif

  @if ($app_services->count())
    <section class="pt-10 pb-10 appear-animate four-items" data-animation-options="{
        'delay': '.3s'
    }">
        <div class="container">
            <div class="title title-sm mt-8 title-center title-custom-underline mb-8 appear-animate">{{config('constant.constant.services.'.$lang)}}</div>
            <div class="owl-carousel owl-theme row cols-lg-4 cols-md-3 cols-sm-2 cols-1" data-owl-options="{
                'nav': true,
                'dots': false,
                'autoplay': false,
                'margin': 20,
                'loop': false,
                'responsive': {
                    '0': {
                        'margin': 0,
                        'items': 1
                    },
                    '576': {
                        'items': 1
                    },
                    '768': {
                        'items': 2
                    },
                    '992': {
                        'items': 3
                    }
                }
            }">
            @foreach ($app_services as $key => $service)
              @include('parts.service')
            @endforeach
          </div>
        </div>
    </section>
  @endif

  @include('home.parts.action')

@endsection
