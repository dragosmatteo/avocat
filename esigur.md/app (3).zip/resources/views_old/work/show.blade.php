@extends('app.master')

@section('meta')
<title>{{ $work->name->$lang }}</title>
<meta name="description" content="{{ $work->title->$lang }}" />

{{-- <meta property="fb:app_id" content="1355208687908995" /> --}}
<meta property="og:type" content="website" />
<meta property="og:url" content="{{url()->current()}}" />
<meta property="og:image"    content="https://casadevis.md/assets/img/casadevis_{{ $lang }}.jpg" />
<meta property="og:title" content="{{ $work->name->$lang }}" />
<meta property="og:description" content="{{ $work->title->$lang }}" />

<script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [{
        "@type": "ListItem",
        "position": 1,
        "name": "{{config('constant.constant.main.'.$lang)}}",
        "item": "{{route('home')}}"
      },{
        "@type": "ListItem",
        "position": 2,
        "name": "{{config('constant.constant.works.'.$lang)}}",
        "item": "{{route('work.index')}}"
      },{
        "@type": "ListItem",
        "position": 3,
        "name": "{{ $work->name->$lang }}"
      }]
    }
</script>
@endsection

@section('header')
<nav class="breadcrumb-nav">
    <div class="container">
        <ul class="breadcrumb">
            <li><a href="{{route('home')}}"><i class="d-icon-home"></i></a></li>
            <li><a href="{{route('work.index')}}">{{config('constant.constant.works.'.$lang)}}</a></li>
            <li>{{$work->name->$lang}}</li>
        </ul>
    </div>
</nav>
@endsection

@section('content')

  @if ($work->position == 0)
    <div class="container pt-10 pb-10">
      <div class="product product-single mb-2">
        <div class="product-gallery product-extended mb-2">
          <div class="product-gallery-carousel owl-carousel owl-theme row cols-1 cols-md-2 cols-lg-3"data-owl-options="{
              'loop': true
          }">
            @if ($work->images)
              @foreach ($work->images as $key => $image)
                @if ($image)
                  <figure class="product-image">
                    <picture>
                      {{-- <source srcset="/files/works/lg/{{$image.'.webp'}}" type="image/webp" media="(min-width: 1025px)">
                      <source srcset="/files/works/lg/{{$image.'.jpg'}}" type="image/jpeg" media="(min-width: 1025px)"> --}}
                      <source srcset="/files/works/md/{{$image.'.webp'}}" type="image/webp" media="(min-width: 1025px)">
                      <source srcset="/files/works/md/{{$image.'.jpg'}}" type="image/jpeg" media="(min-width: 1025px)">
                      <source srcset="/files/works/sm/{{$image.'.webp'}}" type="image/webp">
                      <source srcset="/files/works/sm/{{$image.'.jpg'}}" type="image/jpeg">
                      <img src="/files/works/lg/{{$image.'.jpg'}}" data-src="/files/works/md/{{$image.'.jpg'}}" alt="{{$work->name->$lang}}">
                    </picture>
                  </figure>
                @endif
              @endforeach
            @endif
          </div>
        </div>
      </div>
      @if ($work->body->$lang or $work->link)
        <div class="tab tab-nav-simple product-tabs pb-10">
          <div class="tab-content">
            <div class="tab-pane active in" id="product-tab-description">
              <div class="row d-flex mt-6">
                <div class="col-md-6 order-first order-md-last mb-2">
                  @if ($work->link)
                    <div class="embed-responsive w-100 h-100">
                      <iframe class="embed-responsive-item w-100 h-100" style="border-radius: 10px; min-height: 280px;" src="{{ $work->link }}"></iframe>
                    </div>
                  @endif
                </div>
                <div class="{{ ($work->link)? 'col-md-6' : 'col-md-12' }} order-last order-md-first mb-2">
                  <h1 class="description-title mb-4 font-weight-semi-bold ls-m">{{$work->name->$lang}}</h1>
                  <p class="mb-2">
                    {!! $work->body->$lang !!}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      @endif
    </div>
  @else
    <div class="container pt-10 pb-10">
      <div class="product product-single row">

        @if ($work->body->$lang or $work->link or $work->name->$lang)
          <div class="col-md-12">
            <div class="row d-flex mb-4">
              <div class="col-md-12 mb-2">
                <h1 class="description-title mb-4 font-weight-semi-bold ls-m">{{$work->name->$lang}}</h1>
                <p class="mb-2">
                  {!! $work->body->$lang !!}
                </p>
              </div>
              <div class="col-md-12">
                @if ($work->link)
                  <div class="embed-responsive w-100">
                    <iframe class="embed-responsive-item w-100" style="border-radius: 10px; min-height: 280px;" src="{{ $work->link }}"></iframe>
                  </div>
                @endif
              </div>
            </div>
          </div>
        @endif

        <div class="col-md-12">
          <div class="product-gallery row" style="display: table">
            @if ($work->images)
              @foreach ($work->images as $key => $image)
                @if ($image)
                  <figure class="col-lg-6 d-flex mb-4" style="float: left">
                    <picture>
                      <source srcset="/files/works/lg/{{$image.'.webp'}}" type="image/webp" media="(min-width: 1025px)">
                      <source srcset="/files/works/lg/{{$image.'.jpg'}}" type="image/jpeg" media="(min-width: 1025px)">
                      <source srcset="/files/works/md/{{$image.'.webp'}}" type="image/webp" media="(min-width: 768px)">
                      <source srcset="/files/works/md/{{$image.'.jpg'}}" type="image/jpeg" media="(min-width: 768px)">
                      <source srcset="/files/works/sm/{{$image.'.webp'}}" type="image/webp">
                      <source srcset="/files/works/sm/{{$image.'.jpg'}}" type="image/jpeg">
                      <img class="rounded" src="/files/works/lg/{{$image.'.jpg'}}" data-src="/files/works/md/{{$image.'.jpg'}}" alt="{{$work->name->$lang}}">
                    </picture>
                  </figure>
                @endif
              @endforeach
            @endif
          </div>
        </div>

      </div>
    </div>
  @endif

  <section class="bg_main_1 pt-10 pb-10">
    <div class="container w-100">
        <form method="POST" action="{{route('feedback.store')}}">
            <h4 style="margin-bottom: 0px!important" class="title title-sm title-left title-custom-underline mb-2 appear-animate">{{config('constant.constant.request.'.$lang)}}</h4>
            <br>
            <div class="row mb-2">
              <div class="col-md-6 mb-4">
                  <input style="border-color: white; background: white; border-radius: 6px" class="form_name form-control" type="text" name="name" placeholder="{{config('constant.constant.name.'.$lang)}}" required="required" data-error="{{config('constant.constant.name_error.'.$lang)}}" autocomplete="off">
              </div>
              <div class="col-md-6 mb-4">
                  <input style="border-color: white; background: white; border-radius: 6px" class="form_phone form-control" type="number" name="phone" placeholder="{{config('constant.constant.phone.'.$lang)}}" required="required" data-error="{{config('constant.constant.phone_error.'.$lang)}}" autocomplete="off">
              </div>
              <div class="col-12 mb-4">
                  <textarea style="border-color: white; background: white; border-radius: 6px" class="form-control form_message" rows="4" name="message" placeholder="Комментарий"></textarea>
              </div>
            </div>
            @csrf
            <button class="btn btn-success btn-rounded newsletterbutton">{{config('constant.constant.send.'.$lang)}}</button>
        </form>
    </div>
  </section>

  @if ($works->count())
    <section class="blog-section container pt-10 pb-10 mb-10">
        <h2 class="title font-weight-bold lh-1 mb-5 appear-animate">{{config('constant.constant.similars_works.'.$lang)}}</h2>
        <div class="owl-carousel owl-theme row cols-lg-3 cols-md-2 cols-1" data-owl-options="{
            'items': 3,
            'margin': 20,
            'loop': false,
            'nav': true,
            'dots': false,
            'responsive': {
                '0': {
                    'items': 1
                },
                '576': {
                    'items': 2
                },
                '992': {
                    'items': 3
                }
            }
        }">
        @foreach ($works as $key => $work)
          @include('parts.work')
        @endforeach
        </div>
    </section>
  @endif

@endsection
