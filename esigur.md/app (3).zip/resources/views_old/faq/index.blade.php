@extends('app.master')

@section('meta')
<title>{{config('constant.constant.about_seo_title.'.$lang)}}</title>
<meta name="description" content="{{config('constant.constant.about_seo_desc.'.$lang)}}"/>

{{-- <meta property="fb:app_id" content="1355208687908995" /> --}}
<meta property="og:type"   content="website" />
<meta property="og:url"    content="{{url()->current()}}" />
<meta property="og:image"    content="https://casadevis.md/assets/img/casadevis_{{ $lang }}.jpg" />
<meta property="og:title"  content="{{config('constant.constant.about_seo_title.'.$lang)}}" />
<meta property="og:description"  content="{{config('constant.constant.about_seo_desc.'.$lang)}}" />

<script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [{
        "@type": "ListItem",
        "position": 1,
        "name": "{{config('constant.constant.main.'.$lang)}}",
        "item": "{{route('home')}}"
      },{
        "@type": "ListItem",
        "position": 2,
        "name": "{{config('constant.constant.faq.'.$lang)}}"
      }]
    }
</script>
@endsection

@section('header')
  <div class="product-navigation">
      <div class="container">
          <ul class="breadcrumb breadcrumb-lg">
              <li><a href="{{route('home')}}"><i class="d-icon-home"></i></a></li>
              <li>{{config('constant.constant.faq.'.$lang)}}</li>
          </ul>
      </div>
  </div>
@endsection

@section('content')
  @if ($faqs->count())
    <div class="page-content mb-10 mt-10" itemscope itemtype="https://schema.org/FAQPage">
        <div class="container">
            <div class="product product-single row">
                <div class="col-md-12 order-1 order-lg-2">
                    <div class="accordion accordion-simple mb-4">
                      @foreach ($faqs as $key => $faq)
                        <div class="card card-additional" itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
                            <div class="card-header">
                                <a href="#collapse1-{{$key}}" class="expand">
                                  <span itemprop="name">{{$faq->name->$lang}}</span>
                                </a>
                            </div>
                            <div class="card-body collapsed" id="collapse1-{{$key}}" itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
                                <div itemprop="text">
                                    {!! $faq->body->$lang !!}
                                </div>
                            </div>
                        </div>
                      @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
  @endif

  @include('home.parts.action')
@endsection
