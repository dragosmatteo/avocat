<a title="{{(isset($service->service->link_title->$lang))? $service->service->link_title->$lang : $service->link_title->$lang}}" href="#feedbackFormBlock" class="link-vist service">
  <span class="link-vist-text">{{(isset($service->service->link_title->$lang))? $service->service->link_title->$lang : $service->link_title->$lang}}</span>
  <div class="link-vist-arrow">
    <svg viewBox="0 0 80 80">
      <polyline points="19.89 15.25 64.03 15.25 64.03 59.33"></polyline>
      <line x1="64.03" y1="15.25" x2="14.03" y2="65.18"></line>
    </svg>
  </div>
</a>
