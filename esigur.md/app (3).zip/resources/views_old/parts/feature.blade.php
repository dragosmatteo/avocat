<div class="col-lg-4 col-md-6 col-12 d-flex advantage">
  <div class="icon-box icon-box-side icon-box-side-1 flex-column mb-3 w-100">
      <i class="icon-box-icon mr-0">{{ $loop->iteration }}</i>
      <div class="icon-box-content text-center">
          <div class="icon-box-title text-normal">{{$feature->name->$lang}}</div>
          <p class="font-primary">{{$feature->body->$lang}}</p>
      </div>
  </div>
</div>
