<div class="{{($loop->count <= 2)? 'col-xl-6' : 'col-xl-4'}} col-md-6 col-12 d-flex service-content dsn-up">
    <div class="services-item w-100 d-flex p-relative">
        <div class="after-bg p-absolute w-100 h-100 cover-bg"></div>
        <div class="content">
            {{-- <span class="theme-color">0{{$loop->iteration}}</span> --}}
            <h3 class="title-block ">
              {{$val->name->$lang}}
            </h3>
            <p>{{$val->body->$lang}}</p>
        </div>
    </div>
</div>
