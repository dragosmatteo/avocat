<div class="post post-mask gradient overlay-dark">
    <figure class="post-media">
        <a title="{{$work->name->$lang}}" href="{{route('work.show',$work)}}">
            <picture>
              <source srcset="/files/works/lg/{{$work->image.'.webp'}}" type="image/webp" media="(min-width: 1025px)">
              <source srcset="/files/works/lg/{{$work->image.'.jpg'}}" type="image/jpeg" media="(min-width: 1025px)">
              <source srcset="/files/works/md/{{$work->image.'.webp'}}" type="image/webp" media="(min-width: 768px)">
              <source srcset="/files/works/md/{{$work->image.'.jpg'}}" type="image/jpeg" media="(min-width: 768px)">
              <source srcset="/files/works/sm/{{$work->image.'.webp'}}" type="image/webp">
              <source srcset="/files/works/sm/{{$work->image.'.jpg'}}" type="image/jpeg">
              <img title="{{$work->name->$lang}}" loading="lazy" width="380" height="280" src="/files/works/md/{{$work->image.'.jpg'}}" data-src="/files/works/md/{{$work->image.'.jpg'}}" alt="{{$work->name->$lang}}">
            </picture>
        </a>
    </figure>
    <div class="post-details">
        <h2 class="post-title">
          <a title="{{$work->name->$lang}}" href="{{route('work.show',$work)}}">{{$work->name->$lang}}</a>
        </h2>
        <a title="{{$work->type->name->$lang}}" href="{{route('work.show',$work)}}" class="btn btn-link btn-success">
          {{$work->type->name->$lang}}
        </a>
    </div>
</div>
