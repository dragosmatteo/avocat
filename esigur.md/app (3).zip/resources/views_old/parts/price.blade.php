<div class="awards-item dsn-up" style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">
    <div class="row d-flex align-items-baseline">
        <div class="col-md-4">
            <div class="block-awards">
                <h4 class="sm-title-block ">{{$price->name->$lang}}</h4>
            </div>
        </div>
        <div class="col-md-4">
            <div class="block-awards  text-right">
                @if ($price->price > 0)
                  <div class="sm-title-block ">{{config('constant.constant.from.'.$lang)}} {{$price->price}} {{config('constant.constant.currency.'.$lang)}}</div>
                @else
                  <div class="sm-title-block ">{{config('constant.constant.free.'.$lang)}}</div>  
                @endif

            </div>
        </div>
        <div class="col-md-4">
            <div class="block-awards text-right">
                <a href="#feedbackFormBlock" class="btn p-relative">
                    <span> {{config('constant.constant.talk.'.$lang)}}</span>
                    <div class="icon-circle"></div>
                </a>
            </div>
        </div>
    </div>
</div>
