<div class="post post-image-gap appear-animate"
    data-animation-options="{'name': 'fadeInRightShorter', 'delay': '.5s'}">
    <figure class="post-media">
        <a title="{{$blog->name->$lang}}" href="{{route('blog.show',$blog)}}">
          <picture>
            <source srcset="/files/blogs/thumbs/{{$blog->image.'.webp'}}" type="image/webp">
            <source srcset="/files/blogs/thumbs/{{$blog->image.'.jpg'}}" type="image/jpeg">
            <img itemprop="image" title="{{$blog->name->$lang}}" width="440" height="206" loading="lazy" src="/files/blogs/thumbs/{{$blog->image.'.jpg'}}" data-src="/files/blogs/thumbs/{{$blog->image.'.jpg'}}" alt="{{ $blog->name->$lang }}">
          </picture>
        </a>
        <div class="post-calendar">
            <span class="post-day">{{$blog->created_at->format('d')}}</span>
            <span class="post-month">{{$blog->created_at->format('M')}}</span>
        </div>
    </figure>
    <div class="post-details">
        <h4 class="post-title">
          <a title="{{$blog->name->$lang}}" href="{{route('blog.show',$blog)}}">{{$blog->name->$lang}}</a>
        </h4>
        <p class="post-content">{!! Str::limit(strip_tags($blog->body->$lang), 200) !!}</p>
        <a title="{{$blog->name->$lang}}" href="{{route('blog.show',$blog)}}" class="btn btn-link btn-underline btn-primary btn-md">
          {{config('constant.constant.more.'.$lang)}}
        </a>
    </div>

    <meta itemprop="articleBody" content="{{$blog->title->$lang}}">
    <meta itemprop="author" content="Webcraft IT">
    <meta itemprop="datePublished" content="{{$blog->created_at->format('d M Y')}}">
</div>
