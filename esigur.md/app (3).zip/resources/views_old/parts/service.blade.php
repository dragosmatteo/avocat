<div class="category category-default1 category-absolute banner-radius overlay-zoom">
    <a title="{{$service->subname->$lang}}" href="{{ route('service.show',$service) }}">
        <figure class="category-media" style="background-color: #edd3c7;">
            <picture>
                <source srcset="/files/services/lg/{{$service->image.'.webp'}}" type="image/webp" media="(min-width: 1025px)">
                <source srcset="/files/services/lg/{{$service->image.'.jpg'}}" type="image/jpeg" media="(min-width: 1025px)">
                <source srcset="/files/services/md/{{$service->image.'.webp'}}" type="image/webp" media="(min-width: 769px)">
                <source srcset="/files/services/md/{{$service->image.'.jpg'}}" type="image/jpeg" media="(min-width: 769px)">
                <source srcset="/files/services/sm/{{$service->image.'.webp'}}" type="image/webp">
                <source srcset="/files/services/sm/{{$service->image.'.jpg'}}" type="image/jpeg">
                <img loading="lazy" src="/files/services/lg/{{ $service->image.'.jpg' }}" data-src="/files/services/lg/{{ $service->image.'.jpg' }}" alt="{{$service->name->$lang}}" width="280" height="280">
            </picture>
        </figure>
    </a>
    <div class="category-content text-center">
        <h3 class="category-name w-100 ls-l">
            <a title="{{$service->subname->$lang}}" href="{{ route('service.show',$service) }}">
                {{$service->name->$lang}}
            </a>
        </h3>
        {{-- <p class="w-100">
            <a class="text-left" title="{{$service->subname->$lang}}" href="{{ route('service.show',$service) }}">
                {{$service->subname->$lang}}
            </a>
        </p> --}}
    </div>
</div>
