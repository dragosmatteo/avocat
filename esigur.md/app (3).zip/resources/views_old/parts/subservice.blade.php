<div class="category category-default1 category-absolute banner-radius overlay-zoom">
    <a title="{{$ser->subname->$lang}}" href="{{ route('service.sub.show',[$service, $ser]) }}">
        <figure class="category-media" style="background-color: #edd3c7;">
            <picture>
              <source srcset="/files/services/lg/{{$ser->image.'.webp'}}" type="image/webp" media="(min-width: 1025px)">
              <source srcset="/files/services/lg/{{$ser->image.'.jpg'}}" type="image/jpeg" media="(min-width: 1025px)">
              <source srcset="/files/services/md/{{$ser->image.'.webp'}}" type="image/webp" media="(min-width: 769px)">
              <source srcset="/files/services/md/{{$ser->image.'.jpg'}}" type="image/jpeg" media="(min-width: 769px)">
              <source srcset="/files/services/sm/{{$ser->image.'.webp'}}" type="image/webp">
              <source srcset="/files/services/sm/{{$ser->image.'.jpg'}}" type="image/jpeg">
              <img loading="lazy" src="/files/services/lg/{{ $ser->image.'.jpg' }}" data-src="/files/services/lg/{{ $ser->image.'.jpg' }}" alt="{{$ser->name->$lang}}" width="200" height="200">
            </picture>
        </figure>
    </a>
    <div class="category-content text-center">
        <h3 class="category-name w-100 ls-l">
            <a class=" w-100" title="{{$ser->subname->$lang}}" href="{{ route('service.sub.show',[$service, $ser]) }}">
                {{$ser->name->$lang}}
            </a>
        </h3>
        {{-- <p class="w-100">
            <a class="text-left" title="{{$ser->subname->$lang}}" href="{{ route('service.sub.show',[$service, $ser]) }}">
                {{$ser->subname->$lang}}
            </a>
        </p> --}}
    </div>
</div>
