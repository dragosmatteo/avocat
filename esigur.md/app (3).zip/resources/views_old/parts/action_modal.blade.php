<div id="modalFeedback" class="modal">
  <div class="modal-content d-flex align-items-center justify-content-center">
    <div class="modal-header">
      <span class="close close_modal">&times;</span>
    </div>
    <div class="modal-body">
      <div class="wrapper root-contact overflow-hidden">
        <div class="container section-margin">
          <div class="section-title-2">
            <div class="h2">{{config('constant.constant.action.'.$lang)}}</div>
          </div>
          <div class="row">
            <div class="col-lg-12">
              <div class="form-box">
                <form class="form feedbackFormModal" method="POST" action="{{route('feedback.store')}}">
                  <div class="messages"></div>
                  <div class="input__wrap controls">
                    <div class="row">
                      <div class="col-lg-6">
                        <div class="form-group">
                          <div class="entry">
                            {{-- <label>{{config('constant.constant.name_title.'.$lang)}}</label> --}}
                            <input class="form_name_modal" type="text" name="name" placeholder="{{config('constant.constant.name.'.$lang)}}" required="required" data-error="{{config('constant.constant.name_error.'.$lang)}}" autocomplete="off">
                          </div>
                          <div class="help-block with-errors"></div>
                        </div>
                      </div>
                      <div class="col-lg-6">
                        <div class="form-group">
                          <div class="entry">
                            {{-- <label>{{config('constant.constant.phone_title.'.$lang)}}</label> --}}
                            <input class="form_phone_modal" type="number" name="phone" placeholder="{{config('constant.constant.phone.'.$lang)}}" required="required" data-error="{{config('constant.constant.phone_error.'.$lang)}}" autocomplete="off">
                          </div>
                          <div class="help-block with-errors"></div>
                        </div>
                      </div>
                      <div class="col-lg-12">
                        <div class="form-group">
                          <div class="entry">
                            {{-- <label>{{config('constant.constant.message_title.'.$lang)}}</label> --}}
                            <textarea class="form-control form_message_modal" rows="4" name="message" placeholder="{{config('constant.constant.message.'.$lang)}}"></textarea>
                          </div>
                          <div class="help-block with-errors"></div>
                        </div>
                      </div>

                      @csrf
                      <div class="col-12">
                        <div class="text-center">
                          <div class="image-zoom w-auto d-inline-block" data-dsn="parallax">
                            <button class="btn-form image-zoom newsletterbutton">
                              <span class="label">{{config('constant.constant.send.'.$lang)}}</span>
                              {{-- <span class="icon-c"><i class="fa fa-play-circle"></i> </span> --}}
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>
