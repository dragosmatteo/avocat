{{-- <div class="preloader">
    <div class="preloader-bar">
        <div class="preloader-progress"></div>
    </div>
    <div class="title v-middle">
        <img loading="lazy" src="/files/{{$about->favicon}}" alt="{{ $about->name->$lang }}">
    </div>
</div> --}}
