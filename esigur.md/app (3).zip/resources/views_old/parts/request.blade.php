<section class="about-me dsn-under-header p-relative mb-section">
  <div class="content p-relative">
    <div class="container">
      <div class="row d-flex align-items-center">
        <div class="col-md-8">
          <div class="box">
            <h5 class="title-block">{{(isset($service->service->link_title->$lang))? $service->service->link_title->$lang : $service->link_title->$lang}}</h5>
          </div>
        </div>
        <div class="col-md-4">
          <div class="box">
            <button title="{{(isset($service->service->link_title->$lang))? $service->service->link_title->$lang : $service->link_title->$lang}}" href="#feedbackFormBlock" class="link-custom d-flex a-item-center p-relative user-no-selection">
                <span class="link-text">{{ config('constant.constant.request.'.$lang) }}</span>
                <span class="link-circle p-absolute">
                    <i class="fas fa-long-arrow-alt-right"></i>
                </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="section-bg p-absolute">
    <div class="after-bg p-absolute w-100 h-100 cover-bg">
    </div>
  </div>
</section>
