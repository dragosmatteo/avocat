<section class="next-up next-project p-relative section-padding">
    <div class="bg-section p-absolute w-100 h-100 over-hidden">
        <div class="h-100 before-z-index" data-dsn-grid="move-up" data-overlay="0">
          <picture>
              <source srcset="/files/abouts/lg/{{$about->image.'.webp'}}" type="image/webp" media="(min-width: 1025px)">
              <source srcset="/files/abouts/lg/{{$about->image.'.jpg'}}" type="image/jpeg" media="(min-width: 1025px)">
              <img title="{{$about->name->$lang}}" loading="lazy" class="action cover-bg-img has-top-bottom lazyload" src="/files/abouts/lg/{{$about->image.'.jpg'}}" data-src="/files/abouts/lg/{{$about->image.'.jpg'}}" alt="{{$about->name->$lang}}" >
          </picture>
        </div>
    </div>
    <div class="container p-relative dsn-z-index-2">
        <div class="row margin-lr-100">
            <div class="col-lg-6">
                <div class="next-up-inner p-relative background-section">
                    <div class="title action">{{$about->tagline->$lang}}</div>
                    <a title="{{$about->tagline->$lang}}" href="{{route('contact.index')}}" class="btn background-theme p-relative effect-ajax-none" data-dsn="parallax">
                      {{ config('constant.constant.contact_us.'.$lang) }}
                    </a>

                    <div class="infos d-flex a-item-center bd-highlight">
                        <div class="infos_content mr-auto">{{$about->phone_1}}</div>
                        <div class="infos_button ">
                            <a title="{{$about->tagline->$lang}}" href="{{route('work.index')}}" class="effect-ajax-none image-zoom " data-dsn="parallax">
                              {{ config('constant.constant.works.'.$lang) }}
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="next-up-inner scroll p-relative background-section">
                    @foreach ($app_services_all as $app_service)
                      <div class="seo_title"><a title="{{$app_service->name->$lang}}" href="{{ route('service.show',$app_service) }}">{{ $app_service->name->$lang }}</a></div>
                      <p class="step_body">{!! strip_tags($app_service->body->$lang) !!}</p>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</section>
