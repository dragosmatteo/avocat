@csrf
<footer class="panel-footer">
  <button class="btn btn-primary">СОЗДАТЬ</button>
</footer>
