@csrf
@method('PUT')
<footer class="panel-footer">
  <button class="btn btn-primary">ОБНОВИТЬ</button>
</footer>
