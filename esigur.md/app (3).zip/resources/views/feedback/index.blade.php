@extends('app.master')

@section('meta')
  <title>{{$about->name->$lang}}</title>
  <meta name="description" content="{{$about->title->$lang}}"/>

  <meta property="og:type"   content="website" />
  <meta property="og:url"    content="{{url()->current()}}" />
  <meta property="og:title"  content="{{$about->name->$lang}}" />
  <meta property="og:description"  content="{{$about->title->$lang}}" />
@endsection

@section('content')
  @if (isset($about))
  <div class="box-gallery-vertical box-gallery-content section-margin">
    <div class="container">
      <div class="row align-items-center h-100 dsn-z-index-2">
        <div class="col-lg-5 dsn-z-index-2">
          <div class="box-im">
            <picture>
              <source srcset="/files/abouts/lg/{{$about->image.'.webp'}}" type="image/webp" media="(min-width: 1025px)">
              <source srcset="/files/abouts/lg/{{$about->image.'.jpg'}}" type="image/jpeg" media="(min-width: 1025px)">
              <source srcset="/files/abouts/md/{{$about->image.'.webp'}}" type="image/webp" media="(min-width: 415px)">
              <source srcset="/files/abouts/md/{{$about->image.'.jpg'}}" type="image/jpeg" media="(min-width: 415px)">
              <source srcset="/files/abouts/sm/{{$about->image.'.webp'}}" type="image/webp">
              <source srcset="/files/abouts/sm/{{$about->image.'.jpg'}}" type="image/jpeg">
              <img src="/files/abouts/lg/{{ $about->image.'.jpg' }}" alt="{{$about->name->$lang}}" class="has-top-bottom" data-dsn-move="20%">
            </picture>
          </div>
        </div>
        <div class="col-lg-7">
          <div class="box-info">
            <div style="font-size: 3rem; line-height: 1; padding: 2rem 0; font-weight: 900; color: #008037">{{config('constant.constant.feedback_title.'.$lang)}}</div>

            <h6 style="padding: 2rem 0">
              {{config('constant.constant.feedback_body.'.$lang)}}
            </h6>

            <div style="font-size: 1.5rem; font-weight: 700; color: #000">
              {{config('constant.constant.feedback_add.'.$lang)}}
              <br>
              <a style="font-size: 2rem; color: #FF7824; font-weight: 900;" href="tel:{{$about->phone_1}}">{{$about->phone_1}}</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  @endif
@endsection
